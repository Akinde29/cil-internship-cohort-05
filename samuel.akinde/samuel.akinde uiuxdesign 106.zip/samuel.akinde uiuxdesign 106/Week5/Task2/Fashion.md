# Monday Task. 
https://www.figma.com/file/8Et8s5ZWOj4Tjnuft8kC0H/week5-task-2?node-id=0%3A1

Fashion