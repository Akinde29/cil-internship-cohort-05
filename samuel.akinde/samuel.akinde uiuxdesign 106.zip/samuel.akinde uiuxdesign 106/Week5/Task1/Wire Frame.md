# Monday Task. 
https://www.figma.com/file/jmG446BuAsmrqha6hn8255/Week5-Task-1?node-id=0%3A1

WireFrame