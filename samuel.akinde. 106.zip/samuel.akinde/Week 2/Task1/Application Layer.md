# Monday Task. 
## QUESTION 1: Describe any layered process you are familiar with similar to the OSI model

<b> APPLICATION LAYER:<b/> This is the seventh layer of the OSI model, The layer that humans interact with, examples of the application than human interface with are chrome, Firefox, skype, outlook etc. Application layer interface directly interacts with the application and provides common web application services. 
It depends on application protocols to function, they are embedded with the protocols that are needed to make the connection work HTTP, HTTPS. This layer takes the user input to produce the data to be transferred over the network. It allows user send data, access data and use networks The layer also facilitates communication and sometimes allow users to use software programs.
Application layer examples are: Telnet, File Transfer Protocol(FTP),Hypertext transfer protocol(HTTP).

### Functions of Application Layer
1.	It allows a user to access, retrieve and manage files in a remote computer.
2.	This layer provides services such as e-mail, file transfer, distributing results to users, directory services, network resources, and so on
3.	This layer allows users to interact with other software applications