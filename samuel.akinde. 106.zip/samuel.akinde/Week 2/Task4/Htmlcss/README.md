# Cecure-module-1-Group4
Personal Website (HTML AND CSS), with three pages and a NavBar.

![screencapture-file-C-Users-Lenovo-Desktop-cilNavbar-Cecure-module-1-Group4-home-html-2022-09-06-19_56_16](https://user-images.githubusercontent.com/66309753/188723659-acf4f422-c649-4997-b9c6-3d0924e58ef4.png)
