# CECURE INTELLIGENCE COHORT4 INTERNSHIP

## Thursday Task Module1 Group4

* Code version control
* Branching & merging allow teammembers work concurrently
* Identity: Ensure differnt version of the doc are distinguished from each other
* Staging Area: Formatting and review of code.

 Source code management(SCM) to track modification to a souce code repository.